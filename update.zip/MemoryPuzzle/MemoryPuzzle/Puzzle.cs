using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Media;
using System.Windows.Forms;
using System.Reflection.Emit;
using Timer = System.Threading.Timer;
using System.Diagnostics.Metrics;
using System.Reflection;
using System.Security.Cryptography.Pkcs;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.TextBox;

namespace MemoryPuzzle
{
    public partial class Puzzle : Form
    {
        Random random = new Random();
        bool clicks = false;
        int TickTock = 60;
        PictureBox firstGuess;
        List<String> Pictures = new List<String>()
        {
           "1","1","2","2","3","3","4","4","5","5","6","6","7","7","8","8",
        };
        System.Windows.Forms.Label Click1, CLick2;


        public Puzzle()
        {

            InitializeComponent();

        }
        /*  private void PicToBox()
          {
              System.Windows.Forms.Label Box;
              int rnd;

              for (int i = 0; i < Pictures.Count; i++)
              {
                  if ( )
              }

          }*/
        private void Puzzle_Load(object sender, EventArgs e)
        {

        }

        private void R_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Restarting...");
            Application.Restart();
        }
        private void E_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Game Ended, Exiting...");
            Application.Exit();
        }
        private System.Windows.Forms.Timer timer;
        private void start_Click(object sender, EventArgs e)
        {
            // Sound for start of game
            // System.Media.SoundPlayer player = new System.Media.SoundPlayer(@"c:\mywavfile.wav");
            //   player.Play();
            // Timer for user
            timer = new System.Windows.Forms.Timer();
            timer.Tick += new EventHandler(Time_Tick);
            timer.Interval = 1000; // 1 second
            timer.Start();
            Time.Text = TickTock.ToString();
        }
        private void Time_Tick(object sender, EventArgs e)
        {
            TickTock--;
            if (TickTock == 0)
                timer.Stop();
            Time.Text = TickTock.ToString();
        }
        private void stop_Click(object sender, EventArgs e)
        {
            timer.Stop();
            /*   System.Media.SoundPlayer player = new System.Media.SoundPlayer(@"c:\mywavfile.wav");
               player.Stop();*/
        }
    }
}