﻿
namespace MajorProjectSpaceGame
{
    partial class ProjectSpaceGame
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.PlayerShip = new System.Windows.Forms.PictureBox();
            this.RockObstacle = new System.Windows.Forms.PictureBox();
            this.RotateObj = new System.Windows.Forms.Timer(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.PlayerShip)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.RockObstacle)).BeginInit();
            this.SuspendLayout();
            // 
            // PlayerShip
            // 
            this.PlayerShip.BackColor = System.Drawing.Color.Transparent;
            this.PlayerShip.BackgroundImage = global::MajorProjectSpaceGame.Properties.Resources.TempShip;
            this.PlayerShip.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.PlayerShip.Location = new System.Drawing.Point(534, 540);
            this.PlayerShip.Name = "PlayerShip";
            this.PlayerShip.Size = new System.Drawing.Size(118, 91);
            this.PlayerShip.TabIndex = 0;
            this.PlayerShip.TabStop = false;
            // 
            // RockObstacle
            // 
            this.RockObstacle.BackColor = System.Drawing.Color.Transparent;
            this.RockObstacle.BackgroundImage = global::MajorProjectSpaceGame.Properties.Resources.TempObstacle;
            this.RockObstacle.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.RockObstacle.Location = new System.Drawing.Point(214, 53);
            this.RockObstacle.Name = "RockObstacle";
            this.RockObstacle.Size = new System.Drawing.Size(142, 112);
            this.RockObstacle.TabIndex = 1;
            this.RockObstacle.TabStop = false;
            // 
            // RotateObj
            // 
            this.RotateObj.Enabled = true;
            this.RotateObj.Tick += new System.EventHandler(this.RotateObj_Tick);
            // 
            // ProjectSpaceGame
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.Black;
            this.BackgroundImage = global::MajorProjectSpaceGame.Properties.Resources.Background;
            this.ClientSize = new System.Drawing.Size(1159, 696);
            this.Controls.Add(this.RockObstacle);
            this.Controls.Add(this.PlayerShip);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "ProjectSpaceGame";
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide;
            this.Text = "Space Game";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.ProjectSpaceGame_KeyDown);
            ((System.ComponentModel.ISupportInitialize)(this.PlayerShip)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.RockObstacle)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox PlayerShip;
        private System.Windows.Forms.PictureBox RockObstacle;
        private System.Windows.Forms.Timer RotateObj;
    }
}

