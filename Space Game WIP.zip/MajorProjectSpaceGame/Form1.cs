﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MajorProjectSpaceGame
{
    public partial class ProjectSpaceGame : Form
    {
        private float Angle = 0.0f;

        public ProjectSpaceGame()
        {
            InitializeComponent();
        }

        private void ProjectSpaceGame_KeyDown(object sender, KeyEventArgs e)
        {
            double ShipPosX = PlayerShip.Location.X;
            double ShipPosY = PlayerShip.Location.Y;
            int Speed = 5;

            if (e.KeyCode == Keys.Left)
                PlayerShip.Left -= 20;
            else if (e.KeyCode == Keys.Right)
                PlayerShip.Left += 20;
            else if (e.KeyCode == Keys.Up)
                PlayerShip.Top -= 15;
            else if (e.KeyCode == Keys.Down)
                PlayerShip.Top += 15;
        }

        private void RotateRock(float Angle)
        {
            Bitmap Rotate = new Bitmap(RockObstacle.Image);
            Graphics G = Graphics.FromImage(Rotate);
            G.TranslateTransform((float)Rotate.Width / 2, (float)Rotate.Height / 2);
            G.RotateTransform(Angle);
            G.TranslateTransform(-(float)Rotate.Width / 2, -(float)Rotate.Height / 2);
            RockObstacle.Image = Rotate;
        }

        private void RotateObj_Tick(object sender, EventArgs e)
        {
            Angle += 1.0f;
            RotateRock(Angle);
        }
    }
}
