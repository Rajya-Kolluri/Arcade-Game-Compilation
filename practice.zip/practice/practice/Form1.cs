namespace practice
{
    public partial class Puzzele : Form
    {
        Random random = new Random();
        List<string> Pictures = new List<string>()
        {
            ""
        };
        Label Try1, Try2;
        public Puzzele()
        {
            InitializeComponent();
        }
        public void BoxToPicture()
        {
            Label Box1;
            int RandomPicture;

            for (int i = 0; i < B1.Controls.Count; i++)
            {
                if (B1.Controls[i] is Label)
                    Box1 = (Label)B1.Controls[i];
                else
                    continue;
                RandomPicture = random.Next(0, Pictures.Count);
                Box1.Text = Pictures[RandomPicture];
                Pictures.RemoveAt(RandomPicture);
            }
        }
        private void window_Paint(object sender, PaintEventArgs e)
        {

        }

        private void B1_Click(object sender, EventArgs e)
        {

        }
    }
}