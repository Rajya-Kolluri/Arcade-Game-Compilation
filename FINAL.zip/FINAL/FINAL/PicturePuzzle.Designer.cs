﻿namespace FINAL
{
    partial class PicturePuzzle
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            B1 = new Button();
            B2 = new Button();
            B3 = new Button();
            B4 = new Button();
            B5 = new Button();
            B6 = new Button();
            B7 = new Button();
            B8 = new Button();
            T = new Label();
            Start = new Button();
            s = new Button();
            B = new Button();
            e = new Button();
            panel1 = new Panel();
            pictureBox1 = new PictureBox();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // B1
            // 
            B1.Location = new Point(21, 16);
            B1.Name = "B1";
            B1.Size = new Size(260, 240);
            B1.TabIndex = 0;
            B1.UseVisualStyleBackColor = true;
            B1.Click += B1_Click;
            // 
            // B2
            // 
            B2.Location = new Point(290, 16);
            B2.Name = "B2";
            B2.Size = new Size(260, 240);
            B2.TabIndex = 1;
            B2.UseVisualStyleBackColor = true;
            // 
            // B3
            // 
            B3.Location = new Point(556, 16);
            B3.Name = "B3";
            B3.Size = new Size(260, 240);
            B3.TabIndex = 2;
            B3.UseVisualStyleBackColor = true;
            // 
            // B4
            // 
            B4.Location = new Point(21, 262);
            B4.Name = "B4";
            B4.Size = new Size(260, 240);
            B4.TabIndex = 3;
            B4.UseVisualStyleBackColor = true;
            // 
            // B5
            // 
            B5.Location = new Point(287, 262);
            B5.Name = "B5";
            B5.Size = new Size(260, 240);
            B5.TabIndex = 4;
            B5.UseVisualStyleBackColor = true;
            // 
            // B6
            // 
            B6.Location = new Point(556, 262);
            B6.Name = "B6";
            B6.Size = new Size(260, 240);
            B6.TabIndex = 5;
            B6.UseVisualStyleBackColor = true;
            // 
            // B7
            // 
            B7.Location = new Point(21, 515);
            B7.Name = "B7";
            B7.Size = new Size(260, 240);
            B7.TabIndex = 6;
            B7.UseVisualStyleBackColor = true;
            // 
            // B8
            // 
            B8.Location = new Point(287, 515);
            B8.Name = "B8";
            B8.Size = new Size(260, 240);
            B8.TabIndex = 7;
            B8.UseVisualStyleBackColor = true;
            // 
            // T
            // 
            T.AutoSize = true;
            T.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            T.ForeColor = SystemColors.ButtonHighlight;
            T.Location = new Point(52, 291);
            T.Name = "T";
            T.Size = new Size(83, 45);
            T.TabIndex = 9;
            T.Text = "1:00";
            // 
            // Start
            // 
            Start.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            Start.ForeColor = Color.IndianRed;
            Start.Location = new Point(24, 353);
            Start.Name = "Start";
            Start.Size = new Size(150, 46);
            Start.TabIndex = 10;
            Start.Text = "Start";
            Start.UseVisualStyleBackColor = true;
            Start.Click += Start_Click;
            // 
            // s
            // 
            s.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            s.ForeColor = Color.IndianRed;
            s.Location = new Point(24, 426);
            s.Name = "s";
            s.Size = new Size(150, 46);
            s.TabIndex = 11;
            s.Text = "Stop";
            s.UseVisualStyleBackColor = true;
            s.Click += s_Click;
            // 
            // B
            // 
            B.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            B.ForeColor = Color.IndianRed;
            B.Location = new Point(24, 965);
            B.Name = "B";
            B.Size = new Size(150, 46);
            B.TabIndex = 12;
            B.Text = "Back";
            B.UseVisualStyleBackColor = true;
            B.Click += B_Click;
            // 
            // e
            // 
            e.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            e.ForeColor = Color.IndianRed;
            e.Location = new Point(1090, 12);
            e.Name = "e";
            e.Size = new Size(150, 46);
            e.TabIndex = 13;
            e.Text = "End";
            e.UseVisualStyleBackColor = true;
            e.Click += e_Click;
            // 
            // panel1
            // 
            panel1.Controls.Add(B1);
            panel1.Controls.Add(B2);
            panel1.Controls.Add(B3);
            panel1.Controls.Add(B4);
            panel1.Controls.Add(B6);
            panel1.Controls.Add(B5);
            panel1.Controls.Add(B7);
            panel1.Controls.Add(B8);
            panel1.ForeColor = SystemColors.ButtonHighlight;
            panel1.Location = new Point(265, 143);
            panel1.Name = "panel1";
            panel1.Size = new Size(848, 792);
            panel1.TabIndex = 14;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.main;
            pictureBox1.InitialImage = null;
            pictureBox1.Location = new Point(12, 72);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(236, 177);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 15;
            pictureBox1.TabStop = false;
            // 
            // PicturePuzzle
            // 
            AutoScaleDimensions = new SizeF(13F, 32F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.IndianRed;
            ClientSize = new Size(1282, 1038);
            Controls.Add(pictureBox1);
            Controls.Add(panel1);
            Controls.Add(e);
            Controls.Add(B);
            Controls.Add(s);
            Controls.Add(Start);
            Controls.Add(T);
            Name = "PicturePuzzle";
            Text = "PicturePuzzle";
            panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button B1;
        private Button B2;
        private Button B3;
        private Button B4;
        private Button B5;
        private Button B6;
        private Button B7;
        private Button B8;
        private Label T;
        private Button Start;
        private Button s;
        private Button B;
        private Button e;
        private Panel panel1;
        private PictureBox pictureBox1;
    }
}