﻿namespace FINAL
{
    partial class SignUp
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            OK = new Button();
            name = new TextBox();
            title = new Label();
            label1 = new Label();
            mainImage = new PictureBox();
            ((System.ComponentModel.ISupportInitialize)mainImage).BeginInit();
            SuspendLayout();
            // 
            // OK
            // 
            OK.Font = new Font("Segoe UI", 10.875F, FontStyle.Bold, GraphicsUnit.Point);
            OK.ForeColor = Color.Tan;
            OK.Location = new Point(218, 471);
            OK.Name = "OK";
            OK.Size = new Size(243, 67);
            OK.TabIndex = 0;
            OK.Text = "Sign Up";
            OK.UseVisualStyleBackColor = true;
            OK.Click += OK_Click;
            // 
            // name
            // 
            name.Location = new Point(136, 389);
            name.Name = "name";
            name.Size = new Size(411, 39);
            name.TabIndex = 1;
            // 
            // title
            // 
            title.AutoSize = true;
            title.Font = new Font("Segoe UI", 13.875F, FontStyle.Bold, GraphicsUnit.Point);
            title.ForeColor = Color.Tan;
            title.Location = new Point(192, 93);
            title.Name = "title";
            title.Size = new Size(280, 50);
            title.TabIndex = 2;
            title.Text = "Memory Game";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 7.875F, FontStyle.Bold, GraphicsUnit.Point);
            label1.ForeColor = Color.Tan;
            label1.Location = new Point(136, 356);
            label1.Name = "label1";
            label1.Size = new Size(287, 30);
            label1.TabIndex = 3;
            label1.Text = "Please enter your first name";
            // 
            // mainImage
            // 
            mainImage.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            mainImage.Image = Properties.Resources.main;
            mainImage.Location = new Point(228, 164);
            mainImage.Name = "mainImage";
            mainImage.Size = new Size(189, 189);
            mainImage.SizeMode = PictureBoxSizeMode.StretchImage;
            mainImage.TabIndex = 4;
            mainImage.TabStop = false;
            // 
            // SignUp
            // 
            AutoScaleDimensions = new SizeF(13F, 32F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.WindowFrame;
            ClientSize = new Size(652, 691);
            Controls.Add(mainImage);
            Controls.Add(label1);
            Controls.Add(title);
            Controls.Add(name);
            Controls.Add(OK);
            Name = "SignUp";
            Text = "Sign Up";
            ((System.ComponentModel.ISupportInitialize)mainImage).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button OK;
        private TextBox name;
        private Label title;
        private Label label1;
        private PictureBox mainImage;
    }
}