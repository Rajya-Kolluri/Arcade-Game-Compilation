﻿namespace FINAL
{
    partial class MemoryPuzzle
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            tableLayoutPanel1 = new TableLayoutPanel();
            B12 = new Label();
            B11 = new Label();
            B10 = new Label();
            B9 = new Label();
            B8 = new Label();
            B7 = new Label();
            B6 = new Label();
            B5 = new Label();
            B4 = new Label();
            B3 = new Label();
            B2 = new Label();
            B1 = new Label();
            START = new Button();
            STOP = new Button();
            BACK = new Button();
            EXIT = new Button();
            T = new Label();
            pictureBox1 = new PictureBox();
            timer1 = new System.Windows.Forms.Timer(components);
            tableLayoutPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            tableLayoutPanel1.BackColor = Color.SteelBlue;
            tableLayoutPanel1.CellBorderStyle = TableLayoutPanelCellBorderStyle.OutsetPartial;
            tableLayoutPanel1.ColumnCount = 3;
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 33.3333321F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 33.3333321F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 33.3333321F));
            tableLayoutPanel1.Controls.Add(B12, 2, 3);
            tableLayoutPanel1.Controls.Add(B11, 1, 3);
            tableLayoutPanel1.Controls.Add(B10, 0, 3);
            tableLayoutPanel1.Controls.Add(B9, 2, 2);
            tableLayoutPanel1.Controls.Add(B8, 1, 2);
            tableLayoutPanel1.Controls.Add(B7, 0, 2);
            tableLayoutPanel1.Controls.Add(B6, 2, 1);
            tableLayoutPanel1.Controls.Add(B5, 1, 1);
            tableLayoutPanel1.Controls.Add(B4, 0, 1);
            tableLayoutPanel1.Controls.Add(B3, 2, 0);
            tableLayoutPanel1.Controls.Add(B2, 1, 0);
            tableLayoutPanel1.Controls.Add(B1, 0, 0);
            tableLayoutPanel1.Location = new Point(359, 114);
            tableLayoutPanel1.Name = "tableLayoutPanel1";
            tableLayoutPanel1.RowCount = 4;
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel1.Size = new Size(830, 750);
            tableLayoutPanel1.TabIndex = 0;
            // 
            // B12
            // 
            B12.Dock = DockStyle.Fill;
            B12.Font = new Font("Webdings", 64.875F, FontStyle.Bold, GraphicsUnit.Point);
            B12.ForeColor = Color.SteelBlue;
            B12.Location = new Point(556, 561);
            B12.Name = "B12";
            B12.Size = new Size(268, 186);
            B12.TabIndex = 11;
            B12.TextAlign = ContentAlignment.MiddleCenter;
            B12.Click += Label_Click;
            // 
            // B11
            // 
            B11.Dock = DockStyle.Fill;
            B11.Font = new Font("Webdings", 64.875F, FontStyle.Bold, GraphicsUnit.Point);
            B11.ForeColor = Color.SteelBlue;
            B11.Location = new Point(281, 561);
            B11.Name = "B11";
            B11.Size = new Size(266, 186);
            B11.TabIndex = 10;
            B11.TextAlign = ContentAlignment.MiddleCenter;
            B11.Click += Label_Click;
            // 
            // B10
            // 
            B10.Dock = DockStyle.Fill;
            B10.Font = new Font("Webdings", 64.875F, FontStyle.Bold, GraphicsUnit.Point);
            B10.ForeColor = Color.SteelBlue;
            B10.Location = new Point(6, 561);
            B10.Name = "B10";
            B10.Size = new Size(266, 186);
            B10.TabIndex = 9;
            B10.TextAlign = ContentAlignment.MiddleCenter;
            B10.Click += Label_Click;
            // 
            // B9
            // 
            B9.Dock = DockStyle.Fill;
            B9.Font = new Font("Webdings", 64.875F, FontStyle.Bold, GraphicsUnit.Point);
            B9.ForeColor = Color.SteelBlue;
            B9.Location = new Point(556, 375);
            B9.Name = "B9";
            B9.Size = new Size(268, 183);
            B9.TabIndex = 8;
            B9.TextAlign = ContentAlignment.MiddleCenter;
            B9.Click += Label_Click;
            // 
            // B8
            // 
            B8.Dock = DockStyle.Fill;
            B8.Font = new Font("Webdings", 64.875F, FontStyle.Bold, GraphicsUnit.Point);
            B8.ForeColor = Color.SteelBlue;
            B8.Location = new Point(281, 375);
            B8.Name = "B8";
            B8.Size = new Size(266, 183);
            B8.TabIndex = 7;
            B8.TextAlign = ContentAlignment.MiddleCenter;
            B8.Click += Label_Click;
            // 
            // B7
            // 
            B7.Dock = DockStyle.Fill;
            B7.Font = new Font("Webdings", 64.875F, FontStyle.Bold, GraphicsUnit.Point);
            B7.ForeColor = Color.SteelBlue;
            B7.Location = new Point(6, 375);
            B7.Name = "B7";
            B7.Size = new Size(266, 183);
            B7.TabIndex = 6;
            B7.TextAlign = ContentAlignment.MiddleCenter;
            B7.Click += Label_Click;
            // 
            // B6
            // 
            B6.Dock = DockStyle.Fill;
            B6.Font = new Font("Webdings", 64.875F, FontStyle.Bold, GraphicsUnit.Point);
            B6.ForeColor = Color.SteelBlue;
            B6.Location = new Point(556, 189);
            B6.Name = "B6";
            B6.Size = new Size(268, 183);
            B6.TabIndex = 5;
            B6.TextAlign = ContentAlignment.MiddleCenter;
            B6.Click += Label_Click;
            // 
            // B5
            // 
            B5.Dock = DockStyle.Fill;
            B5.Font = new Font("Webdings", 64.875F, FontStyle.Bold, GraphicsUnit.Point);
            B5.ForeColor = Color.SteelBlue;
            B5.Location = new Point(281, 189);
            B5.Name = "B5";
            B5.Size = new Size(266, 183);
            B5.TabIndex = 4;
            B5.TextAlign = ContentAlignment.MiddleCenter;
            B5.Click += Label_Click;
            // 
            // B4
            // 
            B4.Dock = DockStyle.Fill;
            B4.Font = new Font("Webdings", 64.875F, FontStyle.Bold, GraphicsUnit.Point);
            B4.ForeColor = Color.SteelBlue;
            B4.Location = new Point(6, 189);
            B4.Name = "B4";
            B4.Size = new Size(266, 183);
            B4.TabIndex = 3;
            B4.Text = "u";
            B4.TextAlign = ContentAlignment.MiddleCenter;
            B4.Click += Label_Click;
            // 
            // B3
            // 
            B3.Dock = DockStyle.Fill;
            B3.Font = new Font("Webdings", 64.875F, FontStyle.Bold, GraphicsUnit.Point);
            B3.ForeColor = Color.SteelBlue;
            B3.Location = new Point(556, 3);
            B3.Name = "B3";
            B3.Size = new Size(268, 183);
            B3.TabIndex = 2;
            B3.TextAlign = ContentAlignment.MiddleCenter;
            B3.Click += Label_Click;
            // 
            // B2
            // 
            B2.Dock = DockStyle.Fill;
            B2.Font = new Font("Webdings", 64.875F, FontStyle.Bold, GraphicsUnit.Point);
            B2.ForeColor = Color.SteelBlue;
            B2.Location = new Point(281, 3);
            B2.Name = "B2";
            B2.Size = new Size(266, 183);
            B2.TabIndex = 1;
            B2.TextAlign = ContentAlignment.MiddleCenter;
            B2.Click += Label_Click;
            // 
            // B1
            // 
            B1.AutoSize = true;
            B1.Dock = DockStyle.Fill;
            B1.Font = new Font("Webdings", 64.875F, FontStyle.Bold, GraphicsUnit.Point);
            B1.ForeColor = Color.SteelBlue;
            B1.Location = new Point(6, 3);
            B1.Name = "B1";
            B1.Size = new Size(266, 183);
            B1.TabIndex = 0;
            B1.TextAlign = ContentAlignment.MiddleCenter;
            B1.Click += Label_Click;
            // 
            // START
            // 
            START.Font = new Font("Segoe UI", 10.125F, FontStyle.Bold, GraphicsUnit.Point);
            START.ForeColor = Color.SteelBlue;
            START.Location = new Point(43, 327);
            START.Name = "START";
            START.Size = new Size(150, 46);
            START.TabIndex = 1;
            START.Text = "Start";
            START.UseVisualStyleBackColor = true;
            START.Click += START_Click;
            // 
            // STOP
            // 
            STOP.Font = new Font("Segoe UI", 10.125F, FontStyle.Bold, GraphicsUnit.Point);
            STOP.ForeColor = Color.SteelBlue;
            STOP.Location = new Point(43, 403);
            STOP.Name = "STOP";
            STOP.Size = new Size(150, 46);
            STOP.TabIndex = 2;
            STOP.Text = "Stop";
            STOP.UseVisualStyleBackColor = true;
            STOP.Click += STOP_Click;
            // 
            // BACK
            // 
            BACK.Font = new Font("Segoe UI", 10.125F, FontStyle.Bold, GraphicsUnit.Point);
            BACK.ForeColor = Color.SteelBlue;
            BACK.Location = new Point(43, 895);
            BACK.Name = "BACK";
            BACK.Size = new Size(150, 46);
            BACK.TabIndex = 3;
            BACK.Text = "Back";
            BACK.UseVisualStyleBackColor = true;
            BACK.Click += BACK_Click;
            // 
            // EXIT
            // 
            EXIT.Font = new Font("Segoe UI", 10.125F, FontStyle.Bold, GraphicsUnit.Point);
            EXIT.ForeColor = Color.SteelBlue;
            EXIT.Location = new Point(1120, 895);
            EXIT.Name = "EXIT";
            EXIT.Size = new Size(150, 46);
            EXIT.TabIndex = 4;
            EXIT.Text = "Exit";
            EXIT.UseVisualStyleBackColor = true;
            EXIT.Click += EXIT_Click;
            // 
            // T
            // 
            T.AutoSize = true;
            T.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            T.ForeColor = Color.SteelBlue;
            T.Location = new Point(65, 255);
            T.Name = "T";
            T.Size = new Size(83, 45);
            T.TabIndex = 10;
            T.Text = "1:00";
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.mem;
            pictureBox1.InitialImage = null;
            pictureBox1.Location = new Point(33, 32);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(236, 177);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 11;
            pictureBox1.TabStop = false;
            // 
            // timer1
            // 
            timer1.Interval = 750;
            timer1.Tick += timer1_Tick;
            // 
            // MemoryPuzzle
            // 
            AutoScaleDimensions = new SizeF(13F, 32F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ButtonFace;
            ClientSize = new Size(1315, 970);
            Controls.Add(pictureBox1);
            Controls.Add(T);
            Controls.Add(EXIT);
            Controls.Add(BACK);
            Controls.Add(STOP);
            Controls.Add(START);
            Controls.Add(tableLayoutPanel1);
            ForeColor = Color.SteelBlue;
            Name = "MemoryPuzzle";
            Text = "MemoryPuzzle";
            Click += Label_Click;
            tableLayoutPanel1.ResumeLayout(false);
            tableLayoutPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TableLayoutPanel tableLayoutPanel1;
        private Label B1;
        private Label B12;
        private Label B11;
        private Label B10;
        private Label B9;
        private Label B8;
        private Label B7;
        private Label B6;
        private Label B5;
        private Label B4;
        private Label B3;
        private Label B2;
        private Button START;
        private Button STOP;
        private Button BACK;
        private Button EXIT;
        private Label T;
        private PictureBox pictureBox1;
        private System.Windows.Forms.Timer timer1;
    }
}