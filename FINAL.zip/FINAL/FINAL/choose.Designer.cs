﻿namespace FINAL
{
    partial class choose
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(choose));
            Game2 = new Button();
            T = new Label();
            tt2 = new Label();
            tt1 = new Label();
            E = new Button();
            Game1 = new Button();
            SuspendLayout();
            // 
            // Game2
            // 
            Game2.BackgroundImage = Properties.Resources.main;
            Game2.BackgroundImageLayout = ImageLayout.Zoom;
            Game2.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            Game2.ForeColor = SystemColors.ButtonHighlight;
            Game2.Location = new Point(508, 376);
            Game2.Name = "Game2";
            Game2.Size = new Size(324, 252);
            Game2.TabIndex = 1;
            Game2.UseVisualStyleBackColor = true;
            Game2.Click += Game2_Click;
            // 
            // T
            // 
            T.AutoSize = true;
            T.Font = new Font("Segoe UI", 19.875F, FontStyle.Bold, GraphicsUnit.Point);
            T.ForeColor = SystemColors.ButtonHighlight;
            T.Location = new Point(12, 100);
            T.Name = "T";
            T.Size = new Size(938, 71);
            T.TabIndex = 2;
            T.Text = "Which Game would you like to play?";
            // 
            // tt2
            // 
            tt2.AutoSize = true;
            tt2.BackColor = Color.Transparent;
            tt2.Font = new Font("Segoe UI", 7.875F, FontStyle.Bold, GraphicsUnit.Point);
            tt2.ForeColor = SystemColors.ButtonHighlight;
            tt2.Location = new Point(587, 334);
            tt2.Name = "tt2";
            tt2.Size = new Size(151, 30);
            tt2.TabIndex = 4;
            tt2.Text = "Picture Puzzle";
            // 
            // tt1
            // 
            tt1.AutoSize = true;
            tt1.BackColor = Color.Transparent;
            tt1.Font = new Font("Segoe UI", 7.875F, FontStyle.Bold, GraphicsUnit.Point);
            tt1.ForeColor = SystemColors.ButtonHighlight;
            tt1.Location = new Point(181, 334);
            tt1.Name = "tt1";
            tt1.Size = new Size(165, 30);
            tt1.TabIndex = 5;
            tt1.Text = "Memory Puzzle";
            // 
            // E
            // 
            E.Font = new Font("Segoe UI", 10.125F, FontStyle.Bold, GraphicsUnit.Point);
            E.ForeColor = Color.Tan;
            E.Location = new Point(393, 731);
            E.Name = "E";
            E.Size = new Size(150, 46);
            E.TabIndex = 7;
            E.Text = "Exit";
            E.UseVisualStyleBackColor = true;
            E.Click += E_Click;
            // 
            // Game1
            // 
            Game1.BackgroundImage = (Image)resources.GetObject("Game1.BackgroundImage");
            Game1.BackgroundImageLayout = ImageLayout.Zoom;
            Game1.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            Game1.ForeColor = SystemColors.ButtonHighlight;
            Game1.Location = new Point(109, 376);
            Game1.Name = "Game1";
            Game1.Size = new Size(324, 252);
            Game1.TabIndex = 8;
            Game1.UseVisualStyleBackColor = true;
            Game1.Click += Game1_Click_1;
            // 
            // choose
            // 
            AutoScaleDimensions = new SizeF(13F, 32F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.Tan;
            ClientSize = new Size(982, 803);
            Controls.Add(Game1);
            Controls.Add(E);
            Controls.Add(tt1);
            Controls.Add(tt2);
            Controls.Add(T);
            Controls.Add(Game2);
            Name = "choose";
            Text = "choose";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Button Game2;
        private Label T;
        private Label tt2;
        private Label tt1;
        private Button E;
        private Button Game1;
    }
}