﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace FINAL
{
    public partial class choose : Form
    {
        string Name;
        public choose()
        {
            InitializeComponent();
        }
        private void Game2_Click(object sender, EventArgs e)
        {
            // Create an object of type GameArea
            PicturePuzzle picturepuzzle = new PicturePuzzle();
            this.Hide(); // Hides the current form
            picturepuzzle.ShowDialog(); // Shows the next form
            this.Close(); // Closes the current form
        }
        private void E_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Exiting...");
            Close();
            Application.Exit();
        }

        private void Game1_Click_1(object sender, EventArgs e)
        {
            // Create an object of type GameArea
            MemoryPuzzle memorypuzzle = new MemoryPuzzle();
            this.Hide(); // Hides the current form
            memorypuzzle.ShowDialog(); // Shows the next form
            this.Close(); // Closes the current form
        }
    }
}
