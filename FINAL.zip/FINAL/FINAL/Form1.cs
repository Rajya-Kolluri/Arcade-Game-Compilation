using System.Numerics;
using System.Text.RegularExpressions;
using System.Windows.Forms.Design;

namespace FINAL
{
    public partial class SignUp : Form
    {
        string Name;
        Regex letters_numbers;
        public SignUp()
        {
            InitializeComponent();
            // Expression that accepts only letters and numbers
            letters_numbers = new Regex(@"^[a-zA-Z0-9]+$");
        }
        private void OK_Click(object sender, EventArgs e)
        {

            if (letters_numbers.IsMatch(name.Text))
            {
                // Create an object of type GameArea
                choose choose = new choose();
                this.Hide(); // Hides the current form
                choose.ShowDialog(); // Shows the next form
                this.Close(); // Closes the current form
            }
            else
            {
                MessageBox.Show("Enter a valid Username!");
                name.Text = "";
            }
        }
    }
}