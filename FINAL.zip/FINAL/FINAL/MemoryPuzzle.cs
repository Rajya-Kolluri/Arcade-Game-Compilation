﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FINAL
{
    public partial class MemoryPuzzle : Form
    {
        Random rnd = new Random();
        bool clicks = false;
        int TickTock = 60;

        Label firstClick = null;
        Label secondClick = null;

        List<string> icons = new List<string>()
        {
            "m", "m", "t", "t", "p", "p",
            "o", "o", "b", "b", "Z", "Z"
        };
        public MemoryPuzzle()
        {
            InitializeComponent();
        }
        private void IconsToBox()
        {
            foreach (Control control in tableLayoutPanel1.Controls)
            {
                Label iconLabel = control as Label;
                if (iconLabel != null)
                {
                    int randomNumber = rnd.Next(icons.Count);
                    iconLabel.Text = icons[randomNumber];
                    iconLabel.ForeColor = iconLabel.BackColor;
                    icons.RemoveAt(randomNumber);
                }
            }
        }
        private void label1_Click(object sender, EventArgs e)
        {

        }
        private void CheckForWinner()
        {
            foreach (Control control in tableLayoutPanel1.Controls)
            {
                Label iconLabel = control as Label;

                if (iconLabel != null)
                {
                    if (iconLabel.ForeColor == iconLabel.BackColor)
                        return;
                }
            }
            timer.Stop();
            MessageBox.Show("You WON! with " + TickTock + " Seconds left");
            Close();
            // Create an object of type GameArea
            choose choose = new choose();
            this.Hide(); // Hides the current form
            choose.ShowDialog(); // Shows the next form
            this.Close(); // Closes the current form
        }
        private System.Windows.Forms.Timer timer;
        private void Time_Tick(object sender, EventArgs e)
        {
            TickTock--;
            if (TickTock == 0)
                timer.Stop();
            // MessageBox.Show("You Ran Out of time");
            T.Text = TickTock.ToString();
            T.Text = " :" + TickTock;
        }
        private void START_Click(object sender, EventArgs e)
        {
            timer = new System.Windows.Forms.Timer();
            timer.Tick += new EventHandler(Time_Tick);
            timer.Interval = 1000; // 1 second
            timer.Start();
            T.Text = TickTock.ToString();
            T.Text = "00:" + TickTock;
            IconsToBox();
        }

        private void STOP_Click(object sender, EventArgs e)
        {
            timer.Stop();
            T.Text = " :" + TickTock;
        }

        private void BACK_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Goin Back to home screen...");
            Close();

            choose choose = new choose();
            this.Hide(); // Hides the current form
            choose.ShowDialog(); // Shows the next form
            this.Close(); // Closes the current form
        }

        private void EXIT_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Game Ended, Exiting...");
            Close();
            Application.Exit();
        }

        private void Label_Click(object sender, EventArgs e)
        {
            Label clickedLabel = sender as Label;

            if (firstClick != null && secondClick != null)
                return;

            if (clickedLabel != null)
            {
                if (clickedLabel.ForeColor == Color.White)
                    return;

                if (firstClick == null)
                {
                    firstClick = clickedLabel;
                    firstClick.ForeColor = Color.White;

                    return;
                }
                secondClick = clickedLabel;
                secondClick.ForeColor = Color.White;

                CheckForWinner();

                if (firstClick.Text == secondClick.Text)
                {
                    firstClick = null;
                    secondClick = null;
                    return;
                }
                timer1.Start();
            }
        }
        private void timer1_Tick(object sender, EventArgs e)
        {
            timer1.Stop();

            firstClick.ForeColor = firstClick.BackColor;
            secondClick.ForeColor = secondClick.BackColor;

            firstClick = null;
            secondClick = null;
        }
    }
}
