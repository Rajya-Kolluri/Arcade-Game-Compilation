﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Media;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


//All code here written by M.E.
namespace MajorProjectSpaceGame
{
    public partial class ProjectSpaceGame : Form
    {
        bool moveLeft, moveRight, moveUp, moveDown;
        bool playerShoot, gameOver;
        int shipSpeed = 13, laserSpeed = 18, score = 0, asteroidSpeed = 6, ufoSpeed = 10, spawnTime = 20;
        Bitmap rotateObj;

        Random coor = new Random();
        SoundPlayer playerShootSFX = new SoundPlayer("PlayerShoot.wav");
        SoundPlayer playerLoseSFX = new SoundPlayer("PlayerLose.wav");

        private void ProjectSpaceGame_Load(object sender, EventArgs e)
        {
            SoundPlayer gameBGM = new SoundPlayer("GameBGM.wav");
            gameBGM.PlayLooping();
            playerShoot = false;
        }

        public ProjectSpaceGame()
        {
            InitializeComponent();
        }

        private void ProjectSpaceGame_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Left)
            {
                if (PlayerShip.Right <= 0)
                    PlayerShip.Left = Background.Width;
                else
                    moveLeft = true;
            }
            if (e.KeyCode == Keys.Right)
            {
                if (PlayerShip.Left < Background.Width)
                    moveRight = true;
                else
                    PlayerShip.Left = 0 - PlayerShip.Width;
            }
            if (e.KeyCode == Keys.Up)
            {
                if (PlayerShip.Top <= (0 + (PlayerShip.Height / 2)))
                    moveUp = false;
                else
                    moveUp = true;
            }
            if (e.KeyCode == Keys.Down)
            {
                if (PlayerShip.Bottom < (Background.Height - (PlayerShip.Height / 2)))
                    moveDown = true;
                else
                    moveDown = false;
            }
        }

        private void ProjectSpaceGame_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Left)
            {
                moveLeft = false;
                PlayerShip.BackgroundImage = Properties.Resources.PlayerShip;
            }
            if (e.KeyCode == Keys.Right)
            {
                moveRight = false;
                PlayerShip.BackgroundImage = Properties.Resources.PlayerShip;
            }
            if (e.KeyCode == Keys.Up)
                moveUp = false;
            if (e.KeyCode == Keys.Down)
                moveDown = false;
            if (e.KeyCode == Keys.Space && playerShoot == false)
            {
                playerShoot = true;
                Shoot("Player");
                playerShootSFX.Play();
            }
        }

        private void Shoot(string laserTag)
        {
            PictureBox Laser = new PictureBox();
            Laser.BackgroundImage = Properties.Resources.TempLaser;
            Laser.BackColor = Color.Transparent;
            Laser.BackgroundImageLayout = ImageLayout.Stretch;
            Laser.Size = new Size(45, 60);
            Laser.Tag = laserTag;
            Laser.Left = PlayerShip.Left + PlayerShip.Width / 2;

            if ((string)Laser.Tag == "Player")
            {
                Laser.Top = PlayerShip.Top - 30;
            }

            this.Controls.Add(Laser);
            Laser.BringToFront();
        }

        private void CreateObst(string obstacleTag)
        {
            int x = coor.Next(10, this.ClientSize.Width - 200);

            PictureBox Obstacle = new PictureBox();
            Obstacle.Tag = obstacleTag;

            if (obstacleTag == "Asteroid")
            {
                rotateObj = (Bitmap)Bitmap.FromFile("Asteroid.png");
                rotateObj.RotateFlip(RotateFlipType.Rotate90FlipX);
                Obstacle.Size = new Size(200, 200);
                Obstacle.BackgroundImage = rotateObj;
                Obstacle.BackgroundImageLayout = ImageLayout.Stretch;
                Obstacle.BackColor = Color.Transparent;
                Obstacle.Location = new Point(x, 0 - Obstacle.Height);
            }

            PictureBox UFO = new PictureBox();
            UFO.Size = new Size(120, 120);
            UFO.BackgroundImage = Properties.Resources.UFO;
            UFO.BackgroundImageLayout = ImageLayout.Stretch;
            UFO.BackColor = Color.Transparent;
            UFO.Location = new Point(x, 0 - UFO.Height);

            this.Controls.Add(Obstacle);
            Obstacle.BringToFront();
        }

        private void MainTimer_Tick(object sender, EventArgs e)
        {
            spawnTime -= 1;
            scoreCounter.Text = "SCORE: " + score;

            if (moveLeft)
            {
                PlayerShip.Left -= shipSpeed;
                PlayerShip.BackgroundImage = Properties.Resources.PlayerShip_Left;
            }
            if (moveRight)
            {
                PlayerShip.Left += shipSpeed;
                PlayerShip.BackgroundImage = Properties.Resources.PlayerShip_Right;
            }
            if (moveUp)
                PlayerShip.Top -= shipSpeed;
            if (moveDown)
                PlayerShip.Top += shipSpeed;

            if (spawnTime < 1)
            {
                CreateObst("Asteroid");
                spawnTime = 70;
            }

            foreach (Control Laser in this.Controls)
            {
                if (Laser is PictureBox && (string)Laser.Tag == "Player")
                {
                    Laser.Top -= laserSpeed;
                    playerShoot = false;

                    if (Laser.Top < 5)
                        this.Controls.Remove(Laser);
                }
            }

            foreach (Control Obstacle in this.Controls)
            {
                if (Obstacle is PictureBox && (string)Obstacle.Tag == "Asteroid")
                {
                    Obstacle.Top += asteroidSpeed;
                    if (Obstacle.Top > Background.Bottom)
                        this.Controls.Remove(Obstacle);

                    if (Obstacle.Bounds.IntersectsWith(PlayerShip.Bounds))
                    {
                        this.Controls.Remove(Obstacle);
                        this.Controls.Remove(PlayerShip);
                        playerLoseSFX.Play();
                    }

                    foreach (Control Laser in this.Controls)
                    {
                        if (Laser is PictureBox && (string)Laser.Tag == "Player")
                        {
                            if (Laser.Bounds.IntersectsWith(Obstacle.Bounds))
                            {
                                this.Controls.Remove(Laser);
                                this.Controls.Remove(Obstacle);
                                score += 100;
                            }
                        }
                    }
                }
            }
        }
    }
}
//End M.E.
