﻿
namespace MajorProjectSpaceGame
{
    partial class ProjectSpaceGame
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.MainTimer = new System.Windows.Forms.Timer(this.components);
            this.scoreCounter = new System.Windows.Forms.Label();
            this.PlayerShip = new System.Windows.Forms.PictureBox();
            this.Background = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.PlayerShip)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Background)).BeginInit();
            this.SuspendLayout();
            // 
            // MainTimer
            // 
            this.MainTimer.Enabled = true;
            this.MainTimer.Interval = 10;
            this.MainTimer.Tick += new System.EventHandler(this.MainTimer_Tick);
            // 
            // scoreCounter
            // 
            this.scoreCounter.AutoSize = true;
            this.scoreCounter.BackColor = System.Drawing.Color.Transparent;
            this.scoreCounter.Dock = System.Windows.Forms.DockStyle.Left;
            this.scoreCounter.Font = new System.Drawing.Font("Arial Black", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.scoreCounter.ForeColor = System.Drawing.Color.White;
            this.scoreCounter.Location = new System.Drawing.Point(0, 0);
            this.scoreCounter.Name = "scoreCounter";
            this.scoreCounter.Size = new System.Drawing.Size(173, 42);
            this.scoreCounter.TabIndex = 4;
            this.scoreCounter.Text = "SCORE: 0";
            // 
            // PlayerShip
            // 
            this.PlayerShip.BackColor = System.Drawing.Color.Transparent;
            this.PlayerShip.BackgroundImage = global::MajorProjectSpaceGame.Properties.Resources.PlayerShip;
            this.PlayerShip.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.PlayerShip.Location = new System.Drawing.Point(853, 777);
            this.PlayerShip.Name = "PlayerShip";
            this.PlayerShip.Size = new System.Drawing.Size(118, 91);
            this.PlayerShip.TabIndex = 0;
            this.PlayerShip.TabStop = false;
            // 
            // Background
            // 
            this.Background.BackColor = System.Drawing.Color.Transparent;
            this.Background.BackgroundImage = global::MajorProjectSpaceGame.Properties.Resources.Background;
            this.Background.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Background.Location = new System.Drawing.Point(0, 0);
            this.Background.Name = "Background";
            this.Background.Size = new System.Drawing.Size(1892, 1001);
            this.Background.TabIndex = 2;
            this.Background.TabStop = false;
            // 
            // ProjectSpaceGame
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.Black;
            this.ClientSize = new System.Drawing.Size(1892, 1001);
            this.Controls.Add(this.scoreCounter);
            this.Controls.Add(this.PlayerShip);
            this.Controls.Add(this.Background);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "ProjectSpaceGame";
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide;
            this.Text = "Space Game";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.ProjectSpaceGame_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.ProjectSpaceGame_KeyDown);
            this.KeyUp += new System.Windows.Forms.KeyEventHandler(this.ProjectSpaceGame_KeyUp);
            ((System.ComponentModel.ISupportInitialize)(this.PlayerShip)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Background)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox PlayerShip;
        private System.Windows.Forms.PictureBox Background;
        private System.Windows.Forms.Timer MainTimer;
        private System.Windows.Forms.Label scoreCounter;
    }
}

