﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Media;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MainMenuForm
{
    public partial class SpaceShooterGame : Form
    {
        bool moveLeft, moveRight, moveUp, moveDown;
        bool playerShoot;
        int shipSpeed = 13, laserSpeed = 18, score = 0, asteroidSpeed = 6, ufoSpeed = 10, spawnTime = 20, shootTime = 20, enemyLaserPosX, enemyLaserPosY;
        Bitmap rotateObj;

        PictureBox PlayerShip = new PictureBox();

        Random coor = new Random();

        SoundPlayer gameBGM = new SoundPlayer("GameBGM.wav");
        SoundPlayer playerShootSFX = new SoundPlayer("PlayerShoot.wav");
        SoundPlayer playerLoseSFX = new SoundPlayer("PlayerLose.wav");

        private void SpaceShooterGame_Load(object sender, EventArgs e)
        {
            GameSetup();
        }
        public SpaceShooterGame()
        {
            InitializeComponent();
            Background.BackgroundImage = Properties.Resources.Background;
            PlayerShip.BackgroundImage = Properties.Resources.PlayerShip;
        }

        private void SpaceShooterGame_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Left)
            {
                if (PlayerShip.Right <= 0)
                    PlayerShip.Left = this.ClientSize.Width;
                else
                    moveLeft = true;
            }
            if (e.KeyCode == Keys.Right)
            {
                if (PlayerShip.Left < this.ClientSize.Width)
                    moveRight = true;
                else
                    PlayerShip.Left = 0 - PlayerShip.Width;
            }
            if (e.KeyCode == Keys.Up)
            {
                if (PlayerShip.Top <= (0 + (PlayerShip.Height / 2)))
                    moveUp = false;
                else
                    moveUp = true;
            }
            if (e.KeyCode == Keys.Down)
            {
                if (PlayerShip.Bottom < (this.ClientSize.Height - (PlayerShip.Height / 2)))
                    moveDown = true;
                else
                    moveDown = false;
            }
        }

        private void SpaceShooterGame_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Left)
            {
                moveLeft = false;
                PlayerShip.BackgroundImage = Properties.Resources.PlayerShip;
            }
            if (e.KeyCode == Keys.Right)
            {
                moveRight = false;
                PlayerShip.BackgroundImage = Properties.Resources.PlayerShip;
            }
            if (e.KeyCode == Keys.Up)
                moveUp = false;
            if (e.KeyCode == Keys.Down)
                moveDown = false;
            if (e.KeyCode == Keys.Space && playerShoot == false)
            {
                playerShoot = true;
                Shoot("Player");
                playerShootSFX.Play();
            }
        }
        private void Shoot(string laserTag)
        {
            PictureBox Laser = new PictureBox();
            Laser.BackgroundImage = Properties.Resources.TempLaser;
            Laser.BackColor = Color.Transparent;
            Laser.BackgroundImageLayout = ImageLayout.Stretch;
            Laser.Size = new Size(45, 60);
            Laser.Tag = laserTag;
            Laser.Left = PlayerShip.Left + PlayerShip.Width / 2;

            if ((string)Laser.Tag == "Player")
            {
                Laser.Top = PlayerShip.Top - 30;
            }
            if ((string)Laser.Tag == "Enemy")
            {
                Laser.Top = enemyLaserPosX;
                Laser.Left = enemyLaserPosY;
            }

            this.Controls.Add(Laser);
            Laser.BringToFront();
        }
        private void CreateObst(string obstacleTag)
        {
            int x = coor.Next(10, this.ClientSize.Width - 200);

            PictureBox Obstacle = new PictureBox();
            Obstacle.Tag = obstacleTag;

            if (obstacleTag == "Asteroid")
            {
                rotateObj = (Bitmap)Bitmap.FromFile("Asteroid.png");
                rotateObj.RotateFlip(RotateFlipType.Rotate90FlipX);
                Obstacle.Size = new Size(200, 200);
                Obstacle.BackgroundImage = rotateObj;
                Obstacle.BackgroundImageLayout = ImageLayout.Stretch;
                Obstacle.BackColor = Color.Transparent;
                Obstacle.Location = new Point(x, 0 - Obstacle.Height);
            }

            if (obstacleTag == "UFO")
            {
                Obstacle.Size = new Size(100, 100);
                Obstacle.BackgroundImage = Properties.Resources.UFO;
                Obstacle.BackgroundImageLayout = ImageLayout.Stretch;
                Obstacle.BackColor = Color.Transparent;
                Obstacle.Location = new Point(x, 0 - Obstacle.Height);
            }

            this.Controls.Add(Obstacle);
            Obstacle.BringToFront();
        }
        private void SpaceGameTimer_Tick(object sender, EventArgs e)
        {
            spawnTime -= 1;
            shootTime -= 1;
            scoreCounter.Text = "SCORE: " + score;
            if (score >= 500)
            {
                ufoSpeed = 12;
                asteroidSpeed = 8;
            }

            if (moveLeft)
            {
                PlayerShip.Left -= shipSpeed;
                PlayerShip.BackgroundImage = Properties.Resources.PlayerShip_Left;
            }
            if (moveRight)
            {
                PlayerShip.Left += shipSpeed;
                PlayerShip.BackgroundImage = Properties.Resources.PlayerShip_Right;
            }
            if (moveUp)
                PlayerShip.Top -= shipSpeed;
            if (moveDown)
                PlayerShip.Top += shipSpeed;

            if (spawnTime < 1)
            {
                CreateObst("Asteroid");
                CreateObst("UFO");
                spawnTime = 70;
            }
            if (shootTime < 1)
            {
                Shoot("Enemy");
                shootTime = 70;
            }

            foreach (Control Laser in this.Controls)
            {
                if (Laser is PictureBox && (string)Laser.Tag == "Player")
                {
                    Laser.Top -= laserSpeed;
                    playerShoot = false;

                    if (Laser.Top < 5)
                        this.Controls.Remove(Laser);
                }

                if (Laser is PictureBox && (string)Laser.Tag == "Enemy")
                    Laser.Top += laserSpeed;
            }

            foreach (Control Obstacle in this.Controls)
            {
                if (Obstacle is PictureBox && (string)Obstacle.Tag == "Asteroid")
                {
                    Obstacle.Top += asteroidSpeed;
                    if (Obstacle.Top > Background.Bottom)
                        this.Controls.Remove(Obstacle);

                    if (Obstacle.Bounds.IntersectsWith(PlayerShip.Bounds))
                    {
                        this.Controls.Remove(Obstacle);
                        this.Controls.Remove(PlayerShip);
                        playerLoseSFX.Play();
                        GameEnd();
                    }

                    foreach (Control Laser in this.Controls)
                    {
                        if (Laser is PictureBox && (string)Laser.Tag == "Player")
                        {
                            if (Laser.Bounds.IntersectsWith(Obstacle.Bounds))
                            {
                                this.Controls.Remove(Laser);
                                this.Controls.Remove(Obstacle);
                                score += 10;
                            }
                        }
                    }
                }

                if (Obstacle is PictureBox && (string)Obstacle.Tag == "UFO")
                {
                    enemyLaserPosX = Obstacle.Top;
                    Obstacle.Top += ufoSpeed;
                    if (moveLeft)
                        Obstacle.Left += ufoSpeed;
                    if (moveRight)
                        Obstacle.Left -= ufoSpeed;
                    if (Obstacle.Top > Background.Bottom)
                        this.Controls.Remove(Obstacle);

                    if (Obstacle.Bounds.IntersectsWith(PlayerShip.Bounds))
                    {
                        this.Controls.Remove(Obstacle);
                        this.Controls.Remove(PlayerShip);
                        playerLoseSFX.Play();
                        GameEnd();
                    }

                    foreach (Control Laser in this.Controls)
                    {
                        if (Laser is PictureBox && (string)Laser.Tag == "Player")
                        {
                            if (Laser.Bounds.IntersectsWith(Obstacle.Bounds))
                            {
                                this.Controls.Remove(Laser);
                                this.Controls.Remove(Obstacle);
                                score += 25;
                            }
                        }
                    }
                }
            }
        }

    private void ResetButton_Click(object sender, EventArgs e)
        {
            GameSetup();
        }
     private void ExitButton_Click(object sender, EventArgs e)
        {

            this.Close();
            ArcadeMainMenu main = new ArcadeMainMenu();
            main.Show();
            SoundPlayer menuBGM = new SoundPlayer("MenuBGM.wav");
            menuBGM.Stop();
        }

        private void GameEnd()
        {
            SoundPlayer menuBGM = new SoundPlayer("MenuBGM.wav");
            menuBGM.PlayLooping();
           SpaceGameTimer.Stop();
            for (int i = this.Controls.Count - 1; i >= 0; i--)
            {
                Control element = this.Controls[i];
                if (element != Background)
                {
                    if ((string)element.Tag == "UFO" || (string)element.Tag == "Asteroid" || (string)element.Tag == "Player" || (string)element.Tag == "Enemy")
                    {
                        this.Controls.RemoveAt(i);
                    }
                }

                ExitButton.Visible = true;
                ResetButton.Visible = true;
                Title.Visible = true;
            }
        }

        private void GameSetup()
        {
            gameBGM.PlayLooping();

            Title.Location = new Point((this.ClientSize.Width / 2) - (Title.Width / 2), this.ClientSize.Height / 2);
            ResetButton.Left = this.ClientSize.Width - ResetButton.Width;
            ExitButton.Visible = false;
            ResetButton.Visible = false;
            Title.Visible = false;

            this.Controls.Add(PlayerShip);
            PlayerShip.Size = new Size(120, 90);
            PlayerShip.BackgroundImage = Properties.Resources.PlayerShip;
            PlayerShip.BackgroundImageLayout = ImageLayout.Stretch;
            PlayerShip.Location = new Point(this.ClientSize.Width / 2, this.ClientSize.Height - PlayerShip.Height);
            PlayerShip.BringToFront();

            playerShoot = false;
            score = 0;
            SpaceGameTimer.Start();
        }

    }

}
