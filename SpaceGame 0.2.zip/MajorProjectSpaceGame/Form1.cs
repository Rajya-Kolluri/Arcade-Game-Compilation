﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


//All code here written by M.E.
namespace MajorProjectSpaceGame
{
    public partial class ProjectSpaceGame : Form
    {
        bool moveLeft, moveRight, moveUp, moveDown;
        bool playerShoot, gameOver;
        int shipSpeed = 13, laserSpeed = 18, score = 0, asteroidSpeed = 8, ufoSpeed = 10;

        public ProjectSpaceGame()
        {
            InitializeComponent();
            playerShoot = false;
        }

        private void ProjectSpaceGame_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Left)
                moveLeft = true;
            if (e.KeyCode == Keys.Right)
                moveRight = true;
            if (e.KeyCode == Keys.Up)
                moveUp = true;
            if (e.KeyCode == Keys.Down)
                moveDown = true;
        }

        private void ProjectSpaceGame_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Left)
                moveLeft = false;
            if (e.KeyCode == Keys.Right)
                moveRight = false;
            if (e.KeyCode == Keys.Up)
                moveUp = false;
            if (e.KeyCode == Keys.Down)
                moveDown = false;
            if (e.KeyCode == Keys.Space && playerShoot == false)
            {
                playerShoot = true;
                Shoot("Player");
            }
        }

        private void Shoot(string laserTag)
        {
            PictureBox Laser = new PictureBox();
            Laser.BackgroundImage = Properties.Resources.TempLaser;
            Laser.BackgroundImageLayout = ImageLayout.Stretch;
            Laser.Size = new Size(45, 60);
            Laser.Tag = laserTag;
            Laser.Left = (PlayerShip.Left + PlayerShip.Width) / 2;

            if ((string)Laser.Tag == "Player")
            {
                Laser.Top = PlayerShip.Top - 20;
            }

            this.Controls.Add(Laser);
            Laser.BringToFront();
        }

        private void MainTimer_Tick(object sender, EventArgs e)
        {
            Background.Top += 5;

            if (moveLeft)
                PlayerShip.Left -= shipSpeed;
            if (moveRight)
                PlayerShip.Left += shipSpeed;
            if (moveUp)
                PlayerShip.Top -= shipSpeed;
            if (moveDown)
                PlayerShip.Top += shipSpeed;

            foreach (Control Laser in this.Controls)
            {
                if (Laser is PictureBox && (string)Laser.Tag == "Player")
                {
                    Laser.Top -= laserSpeed;
                    playerShoot = false;

                    if (Laser.Top < 5)
                        this.Controls.Remove(Laser);
                }
            }
        }
    }
}
//End M.E.
